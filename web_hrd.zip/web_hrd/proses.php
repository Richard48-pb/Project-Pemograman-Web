<?php
session_start();

$action = $_POST['action'] ?? '';

switch($action) {
    case 'login':
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        // TODO: Validasi login dengan database
        // Contoh sederhana (ganti dengan query database)
        if($email == 'admin@hris.com' && $password == 'admin123') {
            $_SESSION['user_id'] = 1;
            $_SESSION['nama'] = 'John Doe';
            $_SESSION['email'] = $email;
            header('Location: dashboard.html');
        } else {
            header('Location: index.html?error=1');
        }
        break;
        
    case 'absen_masuk':
        $tanggal = $_POST['tanggal'];
        $waktu = $_POST['waktu'];
        $user_id = $_SESSION['user_id'] ?? 1;
        
        // TODO: Insert ke database absensi
        // INSERT INTO absensi (user_id, tanggal, jam_masuk) VALUES (?, ?, ?)
        
        header('Location: absensi.html?success=masuk');
        break;
        
    case 'absen_pulang':
        $tanggal = $_POST['tanggal'];
        $waktu = $_POST['waktu'];
        $user_id = $_SESSION['user_id'] ?? 1;
        
        // TODO: Update database absensi
        // UPDATE absensi SET jam_pulang = ? WHERE user_id = ? AND tanggal = ?
        
        header('Location: absensi.html?success=pulang');
        break;
        
    case 'ajukan_cuti':
        $jenis_cuti = $_POST['jenis_cuti'];
        $lama_cuti = $_POST['lama_cuti'];
        $tanggal_mulai = $_POST['tanggal_mulai'];
        $tanggal_selesai = $_POST['tanggal_selesai'];
        $keterangan = $_POST['keterangan'];
        $user_id = $_SESSION['user_id'] ?? 1;
        
        // TODO: Handle file upload jika ada
        $file_pendukung = '';
        if(isset($_FILES['file_pendukung']) && $_FILES['file_pendukung']['error'] == 0) {
            // Upload file logic here
        }
        
        // TODO: Insert ke database cuti
        // INSERT INTO cuti (user_id, jenis_cuti, tanggal_mulai, tanggal_selesai, keterangan, status) 
        // VALUES (?, ?, ?, ?, ?, 'menunggu')
        
        header('Location: cuti.html?success=1');
        break;
        
    case 'logout':
        session_destroy();
        header('Location: index.html');
        break;
        
    default:
        header('Location: index.html');
        break;
}
?> 