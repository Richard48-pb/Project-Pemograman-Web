# HRIS System - Frontend

Sistem Informasi Sumber Daya Manusia untuk mencatat absensi dan kehadiran online.

## Fitur

- **Login System**: Halaman login dengan validasi
- **Dashboard**: Tampilan utama dengan ringkasan kehadiran
- **Absensi**: Pencatatan kehadiran masuk dan pulang dengan waktu otomatis
- **Cuti & Izin**: Form pengajuan cuti dan riwayat pengajuan

## Teknologi

- HTML5
- CSS3 (Custom + Bootstrap 5)
- JavaScript (Vanilla)
- Bootstrap 5 (CDN)
- Font Awesome Icons
- Font Poppins dari Google Fonts

## Struktur File

```
web_hrd/
├── index.html      # Halaman login
├── dashboard.html  # Dashboard utama
├── absensi.html    # Halaman absensi
├── cuti.html       # Halaman cuti dan izin
├── style.css       # Custom CSS
└── README.md       # Dokumentasi
```

## Instalasi

1. Copy semua file ke folder `htdocs/web_hrd/` di XAMPP
2. Jalankan Apache di XAMPP Control Panel
3. Buka browser dan akses `http://localhost/web_hrd/`

## Form Actions

Semua form mengirim data ke `proses.php` dengan method POST:

### Login
- action: `login`
- fields: `email`, `password`

### Absensi Masuk
- action: `absen_masuk`
- fields: `tanggal`, `waktu`

### Absensi Pulang
- action: `absen_pulang`
- fields: `tanggal`, `waktu`

### Pengajuan Cuti
- action: `ajukan_cuti`
- fields: `jenis_cuti`, `lama_cuti`, `tanggal_mulai`, `tanggal_selesai`, `keterangan`, `file_pendukung`

### Logout
- action: `logout`

## Database Schema (Referensi)

```sql
-- Tabel Users
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('karyawan', 'hrd')
);

-- Tabel Absensi
CREATE TABLE absensi (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    tanggal DATE,
    jam_masuk TIME,
    jam_pulang TIME,
    status VARCHAR(50)
);

-- Tabel Cuti
CREATE TABLE cuti (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    jenis_cuti VARCHAR(50),
    tanggal_mulai DATE,
    tanggal_selesai DATE,
    keterangan TEXT,
    status ENUM('menunggu', 'disetujui', 'ditolak')
);
```

## Desain

- **Warna**: Biru (#0d6efd), Putih, Abu-abu muda
- **Font**: Poppins
- **Layout**: Responsive dengan Bootstrap Grid
- **Komponen**: Cards, Tables, Forms, Modals

## Browser Support

- Chrome (Recommended)
- Firefox
- Safari
- Edge

## Catatan Pengembangan

- Semua form sudah memiliki validasi client-side
- JavaScript untuk waktu real-time
- Responsive design untuk mobile
- Ready untuk integrasi dengan backend PHP
- Tanpa framework JavaScript untuk kemudahan maintenance 